#include <stdio.h>
#define 	N	20
#define	C	20
int main(){ 

 int Tab[N][C];
 int i,j, n=0, p=0;

	while (n <= 0||n > 20||p <= 0||p > 20){//défintions des limites du programme imposées
		if (i<3) i=i+1; else //Arrêt du programme à la troisième erreur
            {
                printf(" \n Vous avez saisis des valeurs de lignes et de colones incorrectes pour la 3ème  fois... (négatives ou supperieurs à 20). \n Veuillez relancer le programme en respectant les consignes. \n ");
                return 0;
            }
		printf ("Veuillez saisir le nombre positif de ligne sur votre tableau (max 20): ");
		scanf ("%d",&n);
		printf ("Veuillez saisir le nombre positif de colone sur votre tableau (max 20): ");
		scanf ("%d",&p);
		if (n <= 0||n > 20||p <= 0||p > 20){
		printf ("\n Vous avez saisis des valeurs incorrectes... \n Réssayez en utilisant des valeurs positives et inférieurs ou égales à 20 \n");
		printf ("\n");
		}
	}
	
	printf ("Veuillez saisir les %d élements du tableau (séparés par un espace : ", p*n);
	
	for (i=0; i<n; i++){//Placement des valeures de chaque ligne en fonction du nombre de colonne souhaitée 
		for (j=0; j<p; j++)
		scanf("%d", &Tab[i][j]);
	}
	
	  printf("Voici votre tableau multidimentionel : \n");
	  for(i=0; i < n; i++){//Affichage du tableau
	    for(j = 0; j < p; j++){
	      printf("%4d",Tab[i][j]);
	    }
	    printf("\n");
  }
}
