Script started on 2021-10-16 00:07:00+02:00 [TERM="xterm-256color" TTY="/dev/pts/2" COLUMNS="80" LINES="24"]

younes@bgrt:~$ ./tabpoly
Veuillez saisir le nombre positif de ligne sur votre tableau (max 20): -1
Veuillez saisir le nombre positif de colone sur votre tableau (max 20): -1

 Vous avez saisis des valeurs incorrectes... 
 Réssayez en utilisant des valeurs positives et inférieurs ou égales à 20 

Veuillez saisir le nombre positif de ligne sur votre tableau (max 20): 21
Veuillez saisir le nombre positif de colone sur votre tableau (max 20): 21

 Vous avez saisis des valeurs incorrectes... 
 Réssayez en utilisant des valeurs positives et inférieurs ou égales à 20 

Veuillez saisir le nombre positif de ligne sur votre tableau (max 20): 0
Veuillez saisir le nombre positif de colone sur votre tableau (max 20): 0

 Vous avez saisis des valeurs incorrectes... 
 Réssayez en utilisant des valeurs positives et inférieurs ou égales à 20 

 
 Vous avez saisis des valeurs de lignes et de colones incorrectes pour la 3ème  fois... (négatives ou supperieurs à 20). 
 Veuillez relancer le programme en respectant les consignes. 
 
 *****************************************************************
 
younes@bgrt:~$ ./tabpoly
Veuillez saisir le nombre positif de ligne sur votre tableau (max 20):2
Veuillez saisir le nombre positif de colone sur votre tableau (max 20): 3
Veuillez saisir les 6 élements du tableau (séparés par un espace : 1 45 2 4 0 5
Voici votre tableau multidimentionel : 
   1  45   2
   4   0   5

younes@bgrt:~$ exit

Script done on 2021-10-16 00:08:23+02:00 [COMMAND_EXIT_CODE="0"]
