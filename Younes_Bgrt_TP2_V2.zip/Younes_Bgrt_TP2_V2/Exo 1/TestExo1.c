Script started on 2021-10-15 23:58:53+02:00 [TERM="xterm-256color" TTY="/dev/pts/2" COLUMNS="80" LINES="24"];

younes@bgrt:~$ ./tableau_mono
Veuillez saisir la longueur de votre tableau : -1

 Vous avez saisis une valeur incorrecte... 

Veuillez saisir la longueur de votre tableau : 21

 Vous avez saisis une valeur incorrecte... 

Veuillez saisir la longueur de votre tableau : 0

 Vous avez saisis une valeur incorrecte... 

 
 Vous avez saisi une valeur incorrecte pour la 3ème 
 fois (négative ou supérieur à 20). 
 Veuillez relancer le programme en respectant les consignes. 

*************************************************************** 

 younes@bgrt:~$ ./tableau_mono
Veuillez saisir la longueur de votre tableau : 4

 Entrez les 4 valeurs de votre tableau : 
2
1
0
56
i est égal à 4 

 Voici votre tableau monodimentionel : 
    2     1     0    56 
younes@bgrt:~$ exit
exit

Script done on 2021-10-15 23:59:35+02:00 [COMMAND_EXIT_CODE="0"]
