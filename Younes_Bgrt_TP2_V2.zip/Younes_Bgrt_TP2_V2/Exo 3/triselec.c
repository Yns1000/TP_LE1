#include <stdio.h>
#define 	N	20
int main(){ 
	int Tab[N];
	int i, n=0;
	while (n <= 0||n > 20){ //Définition des limites du programme imposées
		if (i<3) i=i+1; else //Arret du programme car saisie incorrecte pour la troisème fois
            {
                printf(" \n Vous avez saisi une valeur incorrecte pour la 3ème fois (négative ou supérieur à 20). \n Veuillez relancer le programme en respectant les consignes. \n ");
                return 0;
            }
		printf ("Veuillez saisir la longueur de votre tableau : ");
		scanf ("%d",&n);
		if (n <= 0||n > 20){
		printf ("\n Vous avez saisis une valeur incorrecte... \n Réssayez en utilisant une valeur positive et inférieur ou égale à 20 \n");
		printf ("\n");
		}
	}
	printf ("\n Entrez les %d valeurs de votre tableau : \n", n);
	for (i=0; i<n; i++){//Insertion des valeurs du tableau
		scanf("%d", &Tab[i]);
	}
//
for (i=0; i<n; i++)// Tri par selection
	for (j=i + 1; j<n; j++)
		if ( Tab[i] > Tab[j] ) {
			min = Tab[i];
			Tab[i] = Tab[j];
			Tab[j] = min;
		}

//
	printf ("i est égal à %d \n", i);
	printf("\n Voici votre tableau monodimentionel : \n");
	for (i=0; i<n ; i++){
		printf("%5d ", Tab[i]);
	}
}
