Script started on 2021-10-16 00:36:38+02:00 [TERM="xterm-256color" TTY="/dev/pts/2" COLUMNS="80" LINES="24"]
younes@bgrt: ~$ ./Triselec
Veuillez saisir la longueur de votre tableau : -1

 Vous avez saisis une valeur incorrecte... 
 Réssayez en utilisant une valeur positive et inférieur ou égale à 20 

Veuillez saisir la longueur de votre tableau : 21

 Vous avez saisis une valeur incorrecte... 
 Réssayez en utilisant une valeur positive et inférieur ou égale à 20 

Veuillez saisir la longueur de votre tableau : 0

 Vous avez saisis une valeur incorrecte... 
 Réssayez en utilisant une valeur positive et inférieur ou égale à 20 

 
 Vous avez saisi une valeur incorrecte pour la 3ème fois (négative ou supérieur à 20). 
 Veuillez relancer le programme en respectant les consignes. 
 
 ***********************************************
 
younes@bgrt:~$ ./Triselec
Veuillez saisir la longueur de votre tableau : 5

 Entrez les 5 valeurs de votre tableau : 
2
78
6
1
0
i est égal à 5 

 Voici votre tableau monodimentionel : 
    0     1     2     6    78 
younes@bgrt:~$ exit
exit

Script done on 2021-10-16 00:37:14+02:00 [COMMAND_EXIT_CODE="0"]
