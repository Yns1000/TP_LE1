/*************************************************************************************************************/
/* B2-Auteur : Boughriet Younes                                                                              */
/* Application :Tp4.c                                                                                        */
/* Date : 01/12/2021                                                                                         */
/* Version : 1.0                                                                                             */ 
/*************************************************************************************************************/

// Soyons SMART : cd Younes_TP4 -> gcc TP4.c -o TP4 && ./Younes_TP4/TP4
// Utiliser https://www.combiendemots.com/ pour compte-rendu 

//Declaration des bibliotheques utilisees
#include <stdio.h>
#include <stdlib.h> //Pour return EXIT_SUCCESS a la fin du main


#define MAXCAR 80
typedef char Tchaine[MAXCAR+1];
//Prototypes des fonctions
char *format (Tchaine  ch);
int strpos(Tchaine m, Tchaine ch);
//char phrase(Tchaine ch1, Tchaine ch2);
char *strmin(Tchaine ch);
char *premier(Tchaine mot, Tchaine chp);
char *saufpremier(const Tchaine mot2, Tchaine chsp);
char * phrase(Tchaine ch1, Tchaine ch2);




int main (){

int choix;
char phrase1[MAXCAR+1], phrase2[MAXCAR+1], nonmod[MAXCAR+1], nonmod2[MAXCAR+1], phrasemin[MAXCAR+1];
char chaine1[MAXCAR+1], mot[MAXCAR+1], chp[MAXCAR+1], phrasep[MAXCAR-1],chmot[MAXCAR-1],mot2[MAXCAR+1], chsp[MAXCAR+1];
int z, o, pos;

printf("\n Bienvenue dans le programme de Younes.\n Afin de ne pas avoir d'erreurs, veuillez inserrer votre première phrase de \n 80 caractères maximum puis la seconde afin de pouvoir utiliser le \n reste du programme correctement.\n Merci. :)\n\n***********************************\n");

  //Declaration des variables
do
{
 
 // Affichage d'un menu
    printf("\n************************************\n*                                  *\n*        😎️MENU PRINCIPAL😎️        *\n*                                  *\n************************************\n\n");
    
    printf("1 - Insertion de la première phrase  \n");
    printf("2 - Insertion de la seconde phrase  \n");
    printf("3 - Recherche \n");
    printf("4 - Affichage des phrases enregistrées (pour test) \n");	
    printf("5 - Convertir une phrase majuscule en minuscule \n");
    printf("6 - Premier mot \n");
    printf("7 - Sauf pemier \n");
    printf("8 - Phrase \n");
    printf("9 - Quitter \n");    
    printf(" Votre choix: ");
    scanf("%d", &choix);
    getchar(); //Suppression du retour chariot qui reste dans le buffer de lecture
    
    switch (choix) 
    {
        case 1 : 
        
        		printf("Veuillez écrire une phrase\n\n");
        		fgets(phrase1, MAXCAR+1, stdin);//On recupere la phrase
        		
        		for (o=0; o<MAXCAR-1; o++)
				nonmod[o]=phrase1[o];//Phrase non modifié dans nonmod
				
        		format(phrase1);//phrase1 formaté dans phrase1
        		

        		printf("Voulez vous formater la phrase ? (1 pour oui | 0 pour non) ");
        		scanf("%d", &z);
        		
        		if (z==1){
        		
			printf("\n");
			printf("Vous avez écris : \n%s\n\n", phrase1); 
			}
			
			else if (z==0){
			
			printf("\n");
			printf("Vous avez écris : \n%s\n\n", nonmod); 
			}
			
			else
			printf("\nChoix incorrect.\n");
				
        break;
        
        case 2 : 
        		printf("Veuillez écrire une autre phrase\n\n");
        		fgets(phrase2, MAXCAR, stdin);
        		
        		for (o=0; o<MAXCAR-1; o++)
				nonmod2[o]=phrase2[o];//Phrase non modifié dans nonmod
				
        		format(phrase2);//phrase1 formaté dans phrase1
        		

        		printf("Voulez vous formater la phrase ? (1 pour oui | 0 pour non) ");
        		scanf("%d", &z);
        		
        		if (z==1){
        		
			printf("\n");
			printf("Vous avez écris : \n%s\n\n", phrase2); 
			}
			
			else if (z==0){
			
			printf("\n");
			printf("Vous avez écris : \n%s\n\n", nonmod2); 
			}
			
			else
			printf("\nChoix incorrect.\n"); 
       
        break;
        
        case 3 : 
        		z=0;
        		
			printf("Grâce à cette fonction vous pouvez rechercher un mot ou un bout de phrase contenue dans la phrase n°2 dans la phrase n°1.\nVoulez vous utilisez les phrases formatées (inserrez 1) ou non (inserrez 0).\n");
			
			scanf("%d", &z);
        		if (z==1){
        		
			printf("\n");
			
			printf("Position = : %d\n\n", strpos(phrase1, phrase2)); 
			}
			else if (z==0){
			
			printf("\n");
			
			printf("Position du premier caractère du mot rechérché dans la phrase 1 = : %d\n\n", strpos(nonmod, nonmod2)); 
			}
		
        break;
        
        case 4 : 
        
        	printf("Phrase 1 : \n%s\n\n", phrase1); 
        	printf("Phrase 1 formatée : \n%s\n\n", nonmod); 
        	printf("Phrase 2 : \n%s\n\n", phrase2); 
        	printf("Phrase 2 formatée : \n%s\n\n", nonmod2); 
			
			
					
        break;
        
        case 5 : 
    
        printf("Veuillez écrire une phrase\n\n");
        		fgets(phrasemin, MAXCAR, stdin); 
        		strmin(phrasemin);	
					
        break;
	
	case 6 : 
        	chmot[MAXCAR-1];
		
		printf("Veuillez écrire une phrase\n\n");
        		fgets(phrasep, MAXCAR, stdin);
		premier(phrasep,chmot);
		printf("%s\n",chmot);
			
			
					
        break;
	case 7 : 

		mot2[MAXCAR-1];
		
		printf("Veuillez écrire une phrase\n\n");
        		fgets(chsp, MAXCAR, stdin);
		
        	saufpremier(chsp,mot2);
		printf("%s\n",mot2);
			
			
					
        break;

        case 8 : 
        	
	phrase(phrase1, phrase2);
	printf("Vous avez écris : \n%s\n\n", phrase1);
			
					
        break;
        
        
        
        
        
        case 9 : printf("Fin de l'application.\n");
                 break;
        default : printf("Cette saisie n'est pas correcte !!! !!! \n");
        printf("\n \n \n");
        
    }    
    
    }
        while (choix!=9);
        
        
        return EXIT_SUCCESS;   
        
	}

/**************************************************************************************************/
/* Fonction : Format                                                                              */
/* Description : Supprime les majuscules avant le debut de la phrase et entre les mots de la      */
/* phrase s'ils sont supérieurs à 1.                                                              */
/* Entrees : Chaine de caractère non formatée.                                                    */
/* Sorties :Chaine de caractère formatée.                                                         */
/* Retourne : Chaine parfaitement formatée                                                        */
/**************************************************************************************************/

char *format (Tchaine ch){

char a;
int i=0, j=0;

	for (i=0;i<MAXCAR-1;i++){//Changement de tab par ' '
			if (ch[i]=='\t')
				ch[i]=' ';
				
			if (ch[i]=='\n')//Supression du \n causé par "enter"
			   ch[i]=ch[i+1];
		}
	ch[i]='\0';
	i=0;
	
	while (ch[0]==32 || ch[0]==9){//Si "espace" (Code ascii = 32) détécté au départ alors on le supprime.
		for (j=0;j<MAXCAR-1;j++){//
		
			a=ch[j+1];
			ch[j]=a;
		}
	j=0; 
	}
	
	for (i=0;i<MAXCAR-1;i++){ //On passe à la detection des espaces à la chaine.
		if (ch[i]==32 && ch[i+1]==32){
			for (j=i;j<MAXCAR-1;j++){
			
				a=ch[j+1];
				ch[j]=a;
			}
		i=0;
		}
	} 
}


/**************************************************************************************************/
/* Fonction : Strpos                                                                              */
/* Description : La fonction strpos retourne la position du mot pointé par m dansla chaine        */
/* pointée par ch sinon -1                                                                        */
/* Entrees : .                                                                                    */
/* Retourne : Position du mot souhaité dans ch1                                                   */
/**************************************************************************************************/

int strpos(Tchaine ch, Tchaine m){
int i=0, j=0, k=0;

	for (i=0; ch[i]!='\0' ; i++){
		
		if (ch[i]==m[j]){
			k=i;//Debut
		while (ch[k]==m[j]){
			k=k+1;
			j=j+1;
		}
		if (m[j]=='\0')
			return i;
		}
	j=0;
	}
			return -1;
}

/**************************************************************************************************/
/* Fonction : Strmin                                                                              */
/* Description : Transforme les majuscules en minuscules                              */
/* Entrees : .                                                   */
/* Sorties :                                                       */
/* Retourne : un pointeur sur le début de cette chaine                                            */
/**************************************************************************************************/
char *strmin(Tchaine ch){
int i=0;
	
	for (i=0; ch[i]!='\0'; i++){
		if (ch[i]>='A' && ch[i]<='Z')
		ch[i]=ch[i]+32;
	}
	
	printf("%s", ch);
}


/**************************************************************************************************/
/* Fonction : premier                                                                              */
/* Description :         */
/*                                                                        */
/* Entrees : .                                                                                    */
/* Retourne : .                                                   */
/**************************************************************************************************/



char *premier(Tchaine mot, Tchaine chp){
int i=0, j=0;

	while (mot[i]!= ' ' && mot[i]!= '\n' && mot[i]!= '\t' && mot[i]!= '\0' ){
		chp[j]=mot[i];
		i=i+1;
		j=j+1;
	}
	chp[i]='\0';
	return chp;
}

/**************************************************************************************************/
/* Fonction : sauf premier                                                                              */
/* Description :        */
/*                                                                         */
/* Entrees : .                                                                                    */
/* Retourne :                                                    */
/**************************************************************************************************/

char *saufpremier (const Tchaine chsp, Tchaine mot2)
{
	int i;
	for(i=0;i<MAXCAR-1;i++){
		mot2[i]=chsp[i];
	}
		for(i=0;i<MAXCAR-1;i++){
			if (chsp[i]!=' ' || chsp[i]!='\0'){
				mot2[i]=' '; 
			}
				if (chsp[i]==32 || chsp[i]==0) {
					format(mot2);
					return(0);
				}
		}
}


/**************************************************************************************************/
/* Fonction : Phrase                                                                             */
/* Description :                                                                         */
/* Entrees : phrase 1 et phrase 2                                                                            */
/* Retourne :une adition de la phrase 1 et 2                                                 */
/**************************************************************************************************/



char *phrase (Tchaine ch1, Tchaine ch2){
int i=0,j=0;
	while(ch1[i]!=0){
		i++;
	}
		ch1[i]=' '; 
		i++;
	while (ch1[i]=ch2[j]){
		j++;
		i++;
	}
}

	


		





