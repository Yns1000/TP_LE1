#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "chaine4.h"
#include "chaine5.h"

/////////Test enlever
#define  MAXCAR 	80
//Definitions de VRAI et FAUX si besoin 
#define	VRAI	1
#define	FAUX	0
////////

//Fonction copie
//sert a créer une copie de la liste entrée en paramètre
void copie(Tchaine ch,Tchaine ch2){
    for (int i=0; i<MAXCAR+1; i++){
        ch2[i]=ch[i];
    }
}

//Fonction NombreChar
//Sert a calculer le nombre de caractère dans une phrase juqu'au \0
int NombreChar(Tchaine phrase){
    int i=0;
    while (phrase[i]!='\0' && i<=MAXCAR+1) {
        i++;
    }
    return i;
}

//Fonction dernier
// Renvoie le dernier mot d'une chaîne de caractère
void dernierMot(Tchaine ch2 , Tchaine dernier)
{
    int i=0;
    int j=0;
    while(ch2[i]!='\0' && i<=MAXCAR+1)
    {
        i++;
    }
    while(ch2[i]!=' ')
    {
        i--;
    }
    while(ch2[i]!='\0')
    {
        dernier[j]=ch2[i];
        i++;
        j++;
    }
    dernier[j]='\0';
}

//Fonction saufdernier
// Renvoie tout la chaîne de caractère sauf le dernier mot
void saufDernier(Tchaine ch2,Tchaine saufdernier)
{
    int i=0;
    while(ch2[i]!='\0' && i<=MAXCAR+1)
    {
        i++;
        saufdernier[i]=ch2[i];
    }
    while(ch2[i]!=' ')
    {
        i--;
    }
    saufdernier[i]='\0';
}

//Fonction dernier
// Renvoie la chaîne de caractèere mais à l'envers
void mirroir(Tchaine ch2 , Tchaine ch1){
    Tchaine chtempo;
    int i=0;
    int j=0;
    int mot=0;
    copie(ch2,chtempo);
    for(int compteur=0 ;ch2[compteur]!='\0';compteur++){
        if(ch2[compteur]==' ')
            mot++;
    }
    i=0;
    for(mot; mot!=0; mot--){
        i=0;
        while(chtempo[i]!='\0' && i<=MAXCAR+1){
            i++;
        }
        while(chtempo[i]!=' '){
            i--;
        }
        chtempo[i]='\0';
        i++;
        while(chtempo[i]!='\0'){
            ch1[j]=chtempo[i];
            i++;
            j++;
        }
        
        ch1[j]=' ';
        j++;
        ch1[j]='\0';
    }
    i=0;
    while(chtempo[i]!=' '){
        ch1[j]=chtempo[i];
        i++;
        j++;
    }
}

// Fonction member
// Retourne 

int member(Tchaine ch, Tchaine ch2, int taille){
    int i=0, j=0;
    while (ch[i]!='\0' && i<MAXCAR+1)
    {
        if (ch2[j]==ch[i])
        {
            j++;
            if (ch2[j+1]==0) 
            {
               
                
                    printf("C'est une sous chaine \n");
                    return 1;
                
            }
        }
        else
        {
            j=0;
        }
        i++;
    }
    printf("Ce n'est pas une sous chaine \n");
    return 0;
}



//Fonction efface
// Renvoie la chaîne de caractère sans le mot chosi
void efface(char ch[], const char mot[])
{
    int pos = strpos(mot, ch);
    int pos2 = pos;
    int compteur=0;
    int i=0;
    int cmp=0;
    if(EGAL(ch,mot)!=0)
    {
        printf("NULL");
    }
    while (ch[i]!='\0')
    {
        i++;
    }

    while (pos!=-1)
    {
            while ((ch[pos2] != '\0') && (ch[pos2] != ' '))
        {
                pos2++;
        compteur++;
            }
            pos2++;
            while (ch[pos2]!='\0')
            {
                ch[pos] = ch[pos2];
                pos++;
                pos2++;
            }
            pos++;
            pos2++;
            ch[pos] = ch[pos2];
            pos = strpos(mot, ch);
            pos2 = pos;
            cmp++;

    }
    if(compteur!=0)
    {
        i=i-compteur;
        ch[i-cmp]='\0';
    }
}

//Fonction afficher
//sert a afficher la liste de caractère
void afficher(Tchaine ch){
    int i=0;
    while (ch[i]!='\0' && i<MAXCAR+1) {
        printf("%c", ch[i]);
        i++;
    }
}

