#ifndef CHAINE5_H

#define CHAINE5_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define	VRAI	1
#define	FAUX	0
#define VIDE(ch) ch[0]=='\0'
#define EGAL(ch1,ch2) strcmp(ch1,ch2)==0

#define MAXCAR 80
typedef char Tchaine[MAXCAR+1];

void dernierMot(Tchaine ch , Tchaine dernier) ;

void saufDernier(Tchaine ch , Tchaine saufdernier);

void mirroir(Tchaine ch2 , Tchaine ch1);

int member(Tchaine ch, Tchaine ch2, int taille);

void efface(char ch[], const char mot[]);

void afficher(Tchaine ch);

void copie(Tchaine ch,Tchaine ch2);

int NombreChar(Tchaine phrase);

#endif
