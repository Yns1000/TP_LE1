/************************************************************************/
/* AUTEUR : Boughriet Younes                                            */
/* DATE : 20/12/2021		                                        */
/* VERSION : 2.0                                                        */
/* DESCRIPTION : Interpreteur de commande                               */
/* NOM FICHIER : tp5.c						        */
/************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "chaine4.h"
#include "chaine5.h"

#define MAX 5

void menu();

int main() {
char cde[MAX] ; // permet de saisir une commande
Tchaine ch,ch2,chtest,chtest2,yih,yih2; // Chaines de caracteres
                 /*0   4   8   12  16  20    24   28   32   36  */
Tchaine ToutSauf1;
int i,j;
char liste_cdes[]="pre-sfp-phr-der-sfd-mir-mmb-eff-hlp-fin"; //Definie la liste des commandes de l'interpreteur
int termine=FAUX ;
int pos ; // variable correspondant a la position de "cde" dans "liste_cdes"

printf("Pour que le programme fonctionne nous avons besoin de deux chaines de caractères...\n\n");

printf("Veuillez insérez une première chaine de caractère\n");
fgets(ch, MAXCAR, stdin);
format(ch);
printf("\n");
printf("Veuillez insérez une seconde chaine de caractère\n");
fgets(ch2, MAXCAR, stdin);
format(ch2);


do{
	menu() ; // Affiche la liste des commandes (a realiser)
	scanf("%d",&pos); //saisir la commande et calculer sa position dans la liste des commandes

switch (pos){ 

case 0 : //Commande premier (pre)
  for (i=0; i<MAXCAR-1; i++)
				chtest[i]=ch[i];
  printf("1er mot= '%s' \n ", premier(chtest2,chtest)) ;
  getchar();
  break ;
  
case 4 : //Commande saufpremier (sfp)

for (i=0; i<MAXCAR-1; i++)
    yih[i]=ch[i];
for (i=0; i<MAXCAR-1; i++)
    yih2[i]=ch2[i];
    
  saufpremier(yih2,yih);
  				printf("\nPhrase n°1 sans premier mot : \n\n%s", yih2);
  				printf("\n\n");
  break; 

case 8 : //Commande phrase (phr)
  
  phrase(ch,ch2);
  format(ch);
  			printf("\nAssemblement de la première phrase insérée et la deuxième : \n%s", ch);
  			printf("\n\n");
  break;


case 12 : //Commande dernier (der)
    
  			dernierMot(ch ,ch2);
  			printf("\nDernier mot de la phrase complète : %s", ch2);
  			printf("\n");
  break;
    
case 16 : //Commande saufdernier (sfd)
        format(ch);
        format(ch2);
  			saufDernier(ch,ch2);
        format(ch2);
  			printf("\nPhrase complète sans le dernier mot : %s", ch2);
 			 printf("\n");
  break;
  break;
  
case 20: //Commande miroir (mir)
    
    mirroir(ch,ch2);
    			printf("\nPhrase inversée : %s",ch2);
    			printf("\n\n");
    break;

case 24 : //Commande member (mmb)
    
    // A completer
  				printf("Veuillez écrire une phrase ou un mot pour voir s'il est sous chaine de phrase : \n");
  				fflush(stdin);
  				getchar();
  fgets(ch2, MAXCAR,stdin);
  				i= NombreChar(ch);
  				member(ch,ch2,i);
  				printf("\n\n");
  break;
  
case 28 : //Commande effacer (eff)
    
    // A completer 
  printf("Mot à effacer ? \n");
  		fflush(stdin);
  		getchar();
  fgets(ch2, MAXCAR,stdin);
  efface(ch,ch2);
  		afficher(ch);
 		 printf("\n\n");
  break;

case 32 : termine=VRAI ;
  		printf("FIN. \n\n");
break ;
default : printf("\007\007 Cde inconnue. Recommencez !!!\n") ;
}
}
while(!termine);
}

void menu()
{

printf("\n************************************\n*                                  *\n*        😎️MENU PRINCIPAL😎️        *\n*                                  *\n************************************\n\n");
    
    printf(" 0 - Premier \n");
    printf(" 4 - Sauf premier \n");
    printf(" 8 - Phrase \n");
    printf(" 12- Dernier \n");	
    printf(" 16- Sauf dernier \n");
    printf(" 20- Mirroir \n");
    printf(" 24- Member \n");
    printf(" 28- Effacer \n");
    printf(" 32 - Quitter \n");
      
    printf(" Votre choix : ");
        printf("\n");
  
}





