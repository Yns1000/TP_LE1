#include <stdio.h>

int main (void) {

int n;
int m;

printf("Inserrez un nombre");

scanf("%d", &n);

m = n*n;

printf (" La somme des %d\n" , n);
printf ("premiers nombres impairs est égale à %d\n", m);
printf ("c'est aussi %d\n" , n);
printf ("au carré");
}




