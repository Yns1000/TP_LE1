#include <stdio.h>

int main (void) {

	int n;
	int i;
	int somme;
	int j;

	printf("Inserrez un nombre");
	scanf("%d", &n);
		for (i=1; i<n; i++){
			somme=0;
			for (j=1; j<i; j++){
				if (i%j == 0){
				somme=somme+j;
				}
			}
			if (somme==i) {
				printf ("%d est un nombre parfait \n", i);
			}
		}
}

