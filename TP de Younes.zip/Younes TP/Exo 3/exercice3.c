#include <stdio.h>
#include <math.h>


int a, b, c, d;
float x1;
float x2;
float x0;
int main ()
{

	printf ("Veuillez saisir a : ");
	scanf ("%d",&a);
	printf ("Veuillez saisir b : ");
	scanf ("%d",&b);
	printf ("Veuillez saisir c : ");
	scanf ("%d",&c);
	
	d = (b*b)+(-4*a*c);
	printf ("Delta est égal à %d \n", d);
	
		if (d>0){
			x1 = (-b-(sqrt(d)))/2*a;
			printf ("X1 est égal à %f \n", x1);
	
			x2 = (-b+(sqrt(d)))/2*a;
			printf ("X2 est égal à %f \n", x2);
		}
		
		if (d==0){
			x0 = -b/2*a;
			printf ("X1 est égal à %f \n", x0);
		}	
		if (d<0) {
			printf ("Votre équation ne comporte pas de solutions réelles :)");
		}
return 0;
}
