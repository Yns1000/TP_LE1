/************************************************************************B1**/
/*Fichier: annuaire.c		                                            */
/*NOM :	Boughriet Younes	    	                       		    */
/* Version : 1.0					                    */
/*Date : 02/01/2022	                                                    */
/*	                                                                    */
/****************************************************************************/
#include <stdio.h>
#include "libannu.h"
#include <sys/time.h> //Necessaire pour utiliser la fonction gettimeofday

/***************************************************************************/
/* NOM FONCTION : menu						            */
/* DESCRIPTION :  Affiche le menu et saisi le choix de l'utilisateur       */
/* Retourne : le choix de l'utilisateur          			   */
/* Effets de bords : Saisie au clavier                                     */
/* Parametres en entree : 						   */
/* Parametres en sortie :                                                  */
/***************************************************************************/
int menu();

int main()
{
Ttabpers Repert; // Repertoire de personne
int dernier; //Position du dernier entre. Mais le 0 c'est pour la sentinnelle
int trouv; // drapeau utilise pour savoir si l'insertion a ete faite
Tchaine nom; //Variable pour saisir le nom de la personne
int rep; // Variable pour saisir les reponses de l'utilisateur pour traiter les options du menu 
int k;
long duree;
long duree2;
int posi;
int taille;
struct timeval debut, fin ;


 //Affichage du menu 
do {
 rep=menu();

 //Traitement de la reponse de la l'utilisateur
switch (rep)
{
    case 1 : printf("\n Saisir un nom :");
        
	     fgets(nom, MAXCAR+1, stdin);
             printf("\n Nom saisi : %s\n",nom);
			 //if (strlen(nom)>MAXCAR)//Si on depasse MAXPERS ca n'ajoute pas (pour tester mettre 5)
			if (dernier >= MAXPERS+1 || strlen(nom)>MAXCAR){//Si on depasse MAXPERS ca n'ajoute pas (pour tester mettre 5)
	printf("PAS POSSIBLE");
	break;
	}
			
	     printf("\n");
	     gettimeofday(&debut,NULL); //Date de debut de la recherche
             if (!chercherpers(Repert,dernier,nom)){
		 gettimeofday(&fin,NULL); 
		 printf("%d", strlen(nom));
                insererpers(Repert,&dernier,nom);
 	     	duree= (fin.tv_sec*1000000+fin.tv_usec)-(debut.tv_sec*1000000+debut.tv_usec);
	printf("\nLa tentative d'insertion a durée %ld us !!\n", duree);
	     }
             if (dernier >= MAXPERS){
	     gettimeofday(&fin,NULL); //Date de fin de la recherche
		printf("\n Le repertoire est plein !!!\n\n");
	     duree= (fin.tv_sec*1000000+fin.tv_usec)-(debut.tv_sec*1000000+debut.tv_usec);
	     printf("\n\nLa tentative d'insertion a durée %ld us !!", duree);
	     }
             break;
    case 2 : printf("\n Saisir un nom :");
             fgets(nom, MAXCAR+1, stdin);
		gettimeofday(&debut,NULL); //Date de debut de la recherche
		k=chercherpers(Repert,dernier,nom);
		gettimeofday(&fin,NULL); 
             printf("\n La position est %d !!! ", k);
		duree= (fin.tv_sec*1000000+fin.tv_usec)-(debut.tv_sec*1000000+debut.tv_usec);
	printf("\nLa recherche a durée %ld us !!\n", duree);
             break;
	getchar();
    case 3 : printf("\n Saisir un nom :");
	     fgets(nom, MAXCAR+1, stdin);
		gettimeofday(&debut,NULL); //Date de debut de la recherche
	     posi=chercherpers(Repert,dernier,nom);
		gettimeofday(&fin,NULL); //Date de fin de la recherche
		duree= (fin.tv_sec*1000000+fin.tv_usec)-(debut.tv_sec*1000000+debut.tv_usec);
	     if (posi==0){
		printf("\nLe contact proposé n'est pas présent dans l'annuaire, nonobstant la recherche du contact a durée %ld us\n", duree);
	        }
		
	     else {
		gettimeofday(&debut,NULL); //Date de debut de la recherche
		supprimerpers(Repert, &dernier, posi);
		gettimeofday(&fin,NULL); //Date de fin de la recherche
		duree2 = duree + ((fin.tv_sec*1000000+fin.tv_usec)-(debut.tv_sec*1000000+debut.tv_usec));
	     printf("\nCe contact qui était à la postion %d a ete supprimée de l'annuaire en %ld us!!!\n", posi,duree2);
		}
                break;
    case 4 : afficherrep(Repert,dernier);
                break;

    case 5 : printf("\n FIN !!!\n\n");
             break;
			 
    default : printf("\n Cas imprevu !!!\n\n");
}
}
while (rep!=5); //On arrete quand l'utilisateur choisi l'option 4

return 1;    
}

/***************************************************************************/
/* NOM FONCTION : menu						           */
/* DESCRIPTION :  Affiche le menu et saisi le choix de l'utilisateur       */
/* Retourne : le choix de l'utilisateur          			   */
/* Effets de bords : Saisie au clavier                                     */
/* Parametres en entree : 						   */
/* Parametres en sortie :                                                  */
/***************************************************************************/
int menu()
{
int choix;  //Permet de saisir la reponse de l'utilisateur

 printf("\n 1-  Entrer un nom de client");
 printf("\n 2-  Rechercher la position d'un client");
 printf("\n 3-  Supprimer un client de l'annuaire");
 printf("\n 4-  Afficher l'annuaire ");
 printf("\n 5-  Quitter");
 printf("\n  Votre choix :"); 
 scanf("%d",&choix);
 getchar();
return choix;

}
 

