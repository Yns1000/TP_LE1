#include "libannu.h"
#include <time.h>
#include <stdlib.h>

int insererpers (Ttabpers Rep, int * der, Tchaine nom) {
int i=*der;


	while (strcmp(Rep[i],nom)>0){   
		strcpy(Rep[i+1],Rep[i]);
		i=i-1;
	}
	
	
	strcpy(Rep[i+1],nom);

	*der = *der + 1;

	return 1;

}


int chercherpers(Ttabpers Rep, int der, Tchaine nom){

int a=1;


	while (strcmp(Rep[a],nom) != 0 && a<=der) 
		a=a+1;
	if (a<= der)
	
	
	return a;
	return 0;
		
}

int supprimerpers(Ttabpers Rep, int *der, int position){
int i;
int pos;
	if (position>*der || position<1) 
	return 0;
	pos=position;
	for (i=position; i<=*der-1;i++){
		strcpy(Rep[i],Rep[i+1]);
	}
	*der=*der-1;
	return pos;
	
}

void afficherrep(Ttabpers Rep, int der){
int j;
	for (j=1; j<=der; j++)
		printf("%s\n",Rep[j]);
}


