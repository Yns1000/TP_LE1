#include <stdio.h>
#include <string.h>

#define MAXCAR 6
#define MAXPERS 15

typedef char Tchaine[MAXCAR+1];
typedef Tchaine Ttabpers[MAXPERS+1];

/*******************************************************************/

int insererpers (Ttabpers Rep, int * der, Tchaine nom);
void afficherrep(Ttabpers Rep, int der);
int chercherpers(Ttabpers Rep, int der, Tchaine nom);
int supprimerpers(Ttabpers Rep, int *der, int position);

